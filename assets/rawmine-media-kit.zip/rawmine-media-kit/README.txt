RawMine — Media Kit
===================

Brand: rawmine.in
Guidelines: https://rawmine.in/brand.html

Colors
------
Accent  #0F766E   links, "Mine", primary buttons
Accent (on dark)  #5EEAD4
Ink     #111418   headings / primary text
Ink 2   #3A414B   body text
Muted   #5B6470   labels, captions
Soft    #F6F8F9   subtle fills
Line    #E7E9EE   borders / dividers
Dark bg #0F1115   social images / icon ground

Typography
----------
System UI stack, weight 800 for the wordmark/headings:
-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif

Files
-----
logo-wordmark-on-light.svg / .png    Horizontal wordmark, TRANSPARENT, for LIGHT backgrounds (ink "Raw" + teal "Mine")
logo-wordmark-on-dark.svg / .png     Horizontal wordmark, TRANSPARENT, for DARK backgrounds (white "Raw" + teal "Mine")
logo-wordmark-solid-dark.svg / .png  Horizontal wordmark, SOLID #0F1115 background (no transparency)
logo-wordmark-solid-light.svg / .png Horizontal wordmark, SOLID #FFFFFF background (no transparency)
logo-1024..16.png               RM monogram, square (avatars, app icons)
favicon.ico                     Multi-res favicon (16/32/48)
og.png            1200x630       Link preview / Open Graph
square.png        1080x1080      Square social post
banner.png        1584x396       Cover banner (LinkedIn, etc.)

Usage
-----
- Keep "Mine" in the accent teal; "Raw" in ink (light bg) or near-white (dark bg).
- Don't lowercase, split into two words, recolor outside the palette, or restretch.
- SVG is preferred wherever it renders; PNGs are for raster-only platforms.
